import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/agent_response.dart';
import '../models/contact_match.dart';
import '../models/tool_execution_result.dart';

import '../services/agent_tts_service.dart';
import '../services/deepgram_service.dart';
import '../services/device_action_service.dart';
import '../services/voice_agent_api_service.dart';

import '../tools/tool_executor.dart';
import '../services/deepgram_voice_agent_service.dart';

enum AgentProvider { customGroq, deepgramVoiceAgent }

enum VoiceUiState {
  idle,
  listening,
  thinking,
  speaking,
  executing,
  success,
  needsInput,
  error,
}

class VoiceAgentScreen extends StatefulWidget {
  const VoiceAgentScreen({super.key});

  @override
  State<VoiceAgentScreen> createState() => _VoiceAgentScreenState();
}

class _VoiceAgentScreenState extends State<VoiceAgentScreen>
    with SingleTickerProviderStateMixin {
  final DeepgramService _deepgram = DeepgramService();

  final AgentTtsService _tts = AgentTtsService();

  AgentProvider _provider = AgentProvider.customGroq;

  late final DeepgramVoiceAgentService _deepgramVoiceAgent;

  StreamSubscription<String>? _transcriptSub;

  StreamSubscription<String>? _finalSub;

  late AnimationController _animation;

  VoiceUiState _state = VoiceUiState.idle;

  String _transcript = '';

  String? _agentMessage;

  bool _processing = false;

  List<ContactMatch> _contacts = [];

  String? _pendingOriginalCommand;

  String? _pendingQuestion;

  final List<Map<String, String>> _conversationHistory = [];

  @override
  void initState() {
    super.initState();

    _deepgramVoiceAgent = DeepgramVoiceAgentService(
      backendUrl: VoiceAgentApiService.baseUrl,

      // No automatic greeting in app mode; user starts the conversation.
      greeting: null,

      onStateChanged: _handleDeepgramAgentState,

      onTranscript: _handleDeepgramAgentTranscript,

      onStatus: (status) {
        debugPrint('Deepgram Agent: $status');
      },

      onError: (code, description) {
        debugPrint(
          'Deepgram Agent Error '
          '$code: $description',
        );

        if (!mounted) return;

        setState(() {
          _state = VoiceUiState.error;

          _agentMessage = description;
        });
      },

      onFunctionCall: (name, arguments) {
        debugPrint(
          'Deepgram function: '
          '$name $arguments',
        );
      },

      onLatencyReport: (report) {
        debugPrint('Deepgram latency: $report');
      },
    );

    _animation = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat();

    _transcriptSub = _deepgram.transcriptStream.listen((value) {
      if (!mounted || _provider != AgentProvider.customGroq) return;

      setState(() {
        _transcript = value;
      });
    });

    _finalSub = _deepgram.finalTranscriptStream.listen((value) {
      if (!mounted || _provider != AgentProvider.customGroq) return;

      setState(() {
        _transcript = value;
      });

      _processCommand(value);
    });
  }

  void _handleDeepgramAgentState(DeepgramVoiceAgentState state) {
    if (!mounted || _provider != AgentProvider.deepgramVoiceAgent) {
      return;
    }

    setState(() {
      switch (state) {
        case DeepgramVoiceAgentState.disconnected:
          // Do not immediately hide a real Settings/WebSocket error.
          if (_state != VoiceUiState.error) {
            _state = VoiceUiState.idle;
          }
          break;

        case DeepgramVoiceAgentState.connecting:
        case DeepgramVoiceAgentState.configuring:
          _state = VoiceUiState.thinking;
          break;

        case DeepgramVoiceAgentState.ready:
          _state = VoiceUiState.idle;
          break;

        case DeepgramVoiceAgentState.listening:
          _state = VoiceUiState.listening;
          break;

        case DeepgramVoiceAgentState.thinking:
          _state = VoiceUiState.thinking;
          break;

        case DeepgramVoiceAgentState.executing:
          _state = VoiceUiState.executing;
          break;

        case DeepgramVoiceAgentState.speaking:
          _state = VoiceUiState.speaking;
          break;

        case DeepgramVoiceAgentState.error:
          _state = VoiceUiState.error;
          break;
      }
    });
  }

  void _handleDeepgramAgentTranscript(DeepgramVoiceAgentTranscript transcript) {
    if (!mounted || _provider != AgentProvider.deepgramVoiceAgent) {
      return;
    }

    setState(() {
      if (transcript.isUser) {
        _transcript = transcript.content;
      }

      if (transcript.isAssistant) {
        _agentMessage = transcript.content;
      }
    });
  }

  Future<void> _switchProvider(AgentProvider provider) async {
    if (_provider == provider) {
      return;
    }

    /*
   * Stop old engine first.
   */
    if (_provider == AgentProvider.customGroq) {
      try {
        await _deepgram.stopListening();
      } catch (_) {}

      try {
        await _tts.stop();
      } catch (_) {}
    }

    if (_provider == AgentProvider.deepgramVoiceAgent) {
      try {
        await _deepgramVoiceAgent.disconnect();
      } catch (_) {}
    }

    if (!mounted) return;

    setState(() {
      _provider = provider;

      _state = VoiceUiState.idle;

      _transcript = '';

      _agentMessage = null;

      _contacts = [];
    });

    HapticFeedback.selectionClick();
  }

  void _rememberConversation(String user, String assistant) {
    _conversationHistory.add({'role': 'user', 'content': user});

    _conversationHistory.add({'role': 'assistant', 'content': assistant});

    /*
   * Keep only recent context.
   *
   * 8 messages = roughly 4 turns.
   */
    if (_conversationHistory.length > 8) {
      _conversationHistory.removeRange(0, _conversationHistory.length - 8);
    }
  }

  // ============================================================
  // MICROPHONE
  // ============================================================

  Widget _providerSelector() {
    return Container(
      margin: const EdgeInsets.fromLTRB(22, 18, 22, 0),

      padding: const EdgeInsets.all(4),

      decoration: BoxDecoration(
        color: const Color(0xFF07111F),

        borderRadius: BorderRadius.circular(16),

        border: Border.all(color: const Color(0xFF17345F)),
      ),

      child: Row(
        children: [
          Expanded(
            child: _providerButton(
              title: 'CUSTOM',

              subtitle: 'GROQ',

              provider: AgentProvider.customGroq,

              icon: Icons.tune_rounded,
            ),
          ),

          Expanded(
            child: _providerButton(
              title: 'DEEPGRAM',

              subtitle: 'VOICE AGENT',

              provider: AgentProvider.deepgramVoiceAgent,

              icon: Icons.blur_on_rounded,
            ),
          ),
        ],
      ),
    );
  }

  Widget _providerButton({
    required String title,
    required String subtitle,
    required AgentProvider provider,
    required IconData icon,
  }) {
    final selected = _provider == provider;

    return GestureDetector(
      onTap: () {
        final busy = _state == VoiceUiState.listening ||
            _state == VoiceUiState.thinking ||
            _state == VoiceUiState.speaking ||
            _state == VoiceUiState.executing;

        if (busy) return;

        _switchProvider(provider);
      },

      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),

        padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 10),

        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),

          gradient: selected
              ? const LinearGradient(
                  colors: [Color(0xFF17489B), Color(0xFF0A74C6)],
                )
              : null,
        ),

        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,

          children: [
            Icon(
              icon,

              size: 17,

              color: selected ? Colors.white : const Color(0xFF637B9F),
            ),

            const SizedBox(width: 8),

            Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                Text(
                  title,

                  style: TextStyle(
                    fontSize: 10,

                    letterSpacing: 1.2,

                    fontWeight: FontWeight.w800,

                    color: selected ? Colors.white : const Color(0xFF8290A6),
                  ),
                ),

                Text(
                  subtitle,

                  style: TextStyle(
                    fontSize: 8,

                    letterSpacing: 1,

                    color: selected
                        ? const Color(0xFF9DD8FF)
                        : const Color(0xFF536279),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  bool get _deepgramAgentCanStop {
    if (_provider != AgentProvider.deepgramVoiceAgent) {
      return false;
    }

    // Only show STOP for a user turn or an audible agent response.
    // The microphone may remain physically active while the agent thinks,
    // but showing STOP during THINKING is misleading.
    return _state == VoiceUiState.listening ||
        _state == VoiceUiState.speaking;
  }

  Future<void> _handleVoiceButton() async {
    if (_provider == AgentProvider.customGroq) {
      await _toggleCustomGroqMic();
      return;
    }

    try {
      // While Priya is speaking, STOP means "stop this response now".
      if (_state == VoiceUiState.speaking) {
        await _deepgramVoiceAgent.stopAgentSpeech();
        return;
      }

      // While the user is speaking, STOP means "this turn is complete".
      // ForceEndTurn is sent, but the persistent microphone stays alive so
      // the next conversational turn does not require another tap.
      if (_state == VoiceUiState.listening) {
        await _deepgramVoiceAgent.finishUserTurn();
        return;
      }

      // Do not fire another control operation while a reply/tool is in flight.
      if (_state == VoiceUiState.thinking ||
          _state == VoiceUiState.executing) {
        return;
      }

      if (mounted) {
        setState(() {
          _transcript = '';
          _agentMessage = null;
          _contacts = [];
        });
      }

      HapticFeedback.mediumImpact();

      if (!_deepgramVoiceAgent.isConnected) {
        await _deepgramVoiceAgent.connect(startMicrophone: true);
      } else {
        await _deepgramVoiceAgent.startListening();
      }
    } catch (error) {
      debugPrint('Deepgram Agent control error: $error');

      if (!mounted) return;
      setState(() {
        _state = VoiceUiState.error;
        _agentMessage = 'Unable to start the Deepgram Voice Agent.';
      });
    }
  }

  Future<void> _toggleCustomGroqMic() async {
    if (_processing ||
        _state == VoiceUiState.speaking ||
        _state == VoiceUiState.executing) {
      return;
    }

    if (_state == VoiceUiState.listening) {
      await _deepgram.stopListening();

      return;
    }

    /*
     * Ensure the agent itself isn't
     * still speaking before we turn
     * microphone back on.
     */
    await _tts.stop();

    HapticFeedback.mediumImpact();

    setState(() {
      _state = VoiceUiState.listening;

      _transcript = '';

      _agentMessage = null;

      _contacts = [];
    });

    try {
      await _deepgram.startListening();
    } catch (e) {
      debugPrint('Microphone error: $e');

      await _showAndSpeak(
        'I couldn\'t access the microphone.',
        VoiceUiState.error,
      );
    }
  }

  // ============================================================
  // PROCESS FINAL TRANSCRIPT
  // ============================================================

  Future<void> _processCommand(String raw) async {
    final command = raw.trim();

    if (command.isEmpty || _processing) {
      return;
    }

    _processing = true;

    setState(() {
      _state = VoiceUiState.thinking;

      _contacts = [];

      /*
       * No spoken intermediate message.
       *
       * UI alone shows processing.
       */
      _agentMessage = null;
    });

    try {
      var input = command;

      /*
       * Multi-turn clarification.
       *
       * Example:
       *
       * "Call someone"
       *
       * Agent:
       * "Who would you like me to call?"
       *
       * User:
       * "Papa"
       */
      if (_pendingOriginalCommand != null && _pendingQuestion != null) {
        input =
            '''
Original request:
"${_pendingOriginalCommand!}"

Assistant asked:
"${_pendingQuestion!}"

User answered:
"$command"

Complete the original request using the answer.
''';
      }

      final AgentResponse response = await VoiceAgentApiService.executeCommand(
        input,
        history: _conversationHistory,
      );

      if (!mounted) return;

      if (response.type == 'ask_user') {
        final message = response.message ?? 'What would you like me to do?';

        _pendingOriginalCommand ??= command;

        _pendingQuestion = message;

        _rememberConversation(command, message);

        await _showAndSpeak(message, VoiceUiState.needsInput);

        return;
      }

      if (response.type == 'assistant_response') {
        final message = response.message ?? 'I don\'t have an answer for that.';

        _clearContext();

        _rememberConversation(command, message);

        await _showAndSpeak(message, VoiceUiState.success);

        return;
      }

      // ========================================================
      // UNSUPPORTED
      // ========================================================

      if (response.type == 'unsupported') {
        _clearContext();

        await _showAndSpeak(
          response.message ?? 'That action isn\'t available yet.',
          VoiceUiState.error,
        );

        return;
      }

      // ========================================================
      // INVALID RESPONSE
      // ========================================================

      if (response.type != 'tool_call' || response.tool == null) {
        throw Exception('Invalid agent response');
      }

      // ========================================================
      // EXECUTE TOOL
      // ========================================================

      final result = await ToolExecutor.execute(
        tool: response.tool!,

        arguments: response.arguments,

        /*
         * Called AFTER the local data
         * required by the action has
         * been resolved, but BEFORE the
         * actual phone action.
         *
         * Example:
         *
         * contact found
         * ↓
         * "Opening the dialer for Papa"
         * ↓
         * speech starts
         * ↓
         * 450 ms
         * ↓
         * dialer opens
         */
        onBeforeAction: (message) async {
          if (!mounted) return;

          setState(() {
            _state = VoiceUiState.speaking;

            _agentMessage = message;
          });

          /*
           * DO NOT wait for the entire
           * sentence to finish.
           *
           * startSpeaking() returns after
           * playback starts.
           */
          try {
            await _tts.startSpeaking(message);
          } catch (e) {
            debugPrint('Action TTS failed: $e');
          }

          /*
           * Small intentional UX delay.
           *
           * User hears:
           *
           * "Opening..."
           *
           * then action happens.
           */
          await Future.delayed(const Duration(milliseconds: 450));

          if (!mounted) return;

          setState(() {
            _state = VoiceUiState.executing;
          });
        },
      );

      if (!mounted) return;

      // ========================================================
      // TOOL RESULT
      // ========================================================

      switch (result.status) {
        case ToolExecutionStatus.completed:

          /*
           * Do NOT speak again.
           *
           * This was already spoken in
           * onBeforeAction.
           */
          setState(() {
            _state = VoiceUiState.success;

            _agentMessage = result.message;
          });

          HapticFeedback.lightImpact();

          break;

        case ToolExecutionStatus.needsContactSelection:

          /*
           * No action happened yet.
           *
           * So speak this whole message.
           */
          await _showAndSpeak(result.message, VoiceUiState.needsInput);

          if (!mounted) return;

          setState(() {
            _contacts = result.contacts;
          });

          break;

        case ToolExecutionStatus.error:

          /*
           * Error is useful information,
           * so speak the entire message.
           */
          await _showAndSpeak(result.message, VoiceUiState.error);

          break;
      }

      _clearContext();
    } catch (e) {
      debugPrint('Agent error: $e');

      await _showAndSpeak(
        'I couldn\'t complete that request. Please try again.',
        VoiceUiState.error,
      );
    } finally {
      _processing = false;
    }
  }

  // ============================================================
  // CONTACT SELECTION
  // ============================================================

  Future<void> _selectContact(ContactMatch contact) async {
    final message = 'Opening the dialer for ${contact.name}.';

    setState(() {
      _contacts = [];

      _state = VoiceUiState.speaking;

      _agentMessage = message;
    });

    /*
     * Start speaking.
     *
     * Do not wait for the sentence
     * to finish.
     */
    try {
      await _tts.startSpeaking(message);
    } catch (e) {
      debugPrint('Contact TTS failed: $e');
    }

    await Future.delayed(const Duration(milliseconds: 450));

    try {
      if (!mounted) return;

      setState(() {
        _state = VoiceUiState.executing;
      });

      await DeviceActionService.dialNumber(phoneNumber: contact.phoneNumber);

      if (!mounted) return;

      setState(() {
        _state = VoiceUiState.success;

        _agentMessage = message;
      });

      HapticFeedback.lightImpact();
    } catch (e) {
      debugPrint('Dialer error: $e');

      await _showAndSpeak('I couldn\'t open the dialer.', VoiceUiState.error);
    }
  }

  // ============================================================
  // SPEAK COMPLETE RESPONSE
  // ============================================================

  Future<void> _showAndSpeak(String message, VoiceUiState finalState) async {
    if (!mounted) return;

    setState(() {
      _state = VoiceUiState.speaking;

      _agentMessage = message;
    });

    /*
     * Here we DO wait until TTS
     * completely finishes.
     *
     * Used for:
     *
     * - errors
     * - clarification questions
     * - unsupported commands
     * - contact selection questions
     */
    try {
      await _tts.speakAndWait(message);
    } catch (e) {
      debugPrint('TTS error: $e');
    }

    if (!mounted) return;

    setState(() {
      _state = finalState;
    });
  }

  void _clearContext() {
    _pendingOriginalCommand = null;

    _pendingQuestion = null;
  }

  // ============================================================
  // STATE
  // ============================================================

  String get _statusText {
    switch (_state) {
      case VoiceUiState.idle:
        return 'SYSTEM READY';

      case VoiceUiState.listening:
        return 'LISTENING';

      case VoiceUiState.thinking:
        return 'NEURAL ROUTING';

      case VoiceUiState.speaking:
        return 'RESPONDING';

      case VoiceUiState.executing:
        return 'EXECUTING';

      case VoiceUiState.success:
        return 'ACTION COMPLETE';

      case VoiceUiState.needsInput:
        return 'INPUT REQUIRED';

      case VoiceUiState.error:
        return 'ACTION BLOCKED';
    }
  }

  IconData get _coreIcon {
    switch (_state) {
      case VoiceUiState.listening:
        return Icons.graphic_eq_rounded;

      case VoiceUiState.thinking:
        return Icons.auto_awesome_rounded;

      case VoiceUiState.speaking:
        return Icons.waves_rounded;

      case VoiceUiState.executing:
        return Icons.bolt_rounded;

      case VoiceUiState.success:
        return Icons.check_rounded;

      case VoiceUiState.error:
        return Icons.close_rounded;

      default:
        return Icons.memory_rounded;
    }
  }

  String get _engineDescription {
    switch (_provider) {
      case AgentProvider.customGroq:
        return 'FLUX STT • GPT-OSS • FLUX TTS';

      case AgentProvider.deepgramVoiceAgent:
        return 'FLUX • CLAUDE 4.6 • PRIYA';
    }
  }

  // ============================================================
  // UI
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF02050A),

      body: Stack(
        children: [
          _background(),

          SafeArea(
            child: Column(
              children: [
                _header(),

                _providerSelector(),

                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),

                    padding: const EdgeInsets.symmetric(horizontal: 22),

                    child: Column(
                      children: [
                        const SizedBox(height: 38),

                        _agentCore(),

                        const SizedBox(height: 28),

                        _status(),

                        const SizedBox(height: 28),

                        if (_transcript.isNotEmpty) _transcriptView(),

                        if (_agentMessage != null) ...[
                          const SizedBox(height: 14),

                          _responseView(),
                        ],

                        if (_contacts.isNotEmpty) _contactView(),

                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),

                _bottomControls(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _background() {
    return Stack(
      children: [
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,

              end: Alignment.bottomCenter,

              colors: [Color(0xFF02050A), Color(0xFF050B15), Color(0xFF02050A)],
            ),
          ),
        ),

        Positioned(
          top: -150,
          right: -130,

          child: Container(
            width: 380,
            height: 380,

            decoration: const BoxDecoration(
              shape: BoxShape.circle,

              gradient: RadialGradient(
                colors: [Color(0x332F6BFF), Color(0x0002050A)],
              ),
            ),
          ),
        ),

        Positioned(
          bottom: -160,
          left: -160,

          child: Container(
            width: 400,
            height: 400,

            decoration: const BoxDecoration(
              shape: BoxShape.circle,

              gradient: RadialGradient(
                colors: [Color(0x2200C8FF), Color(0x0002050A)],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 18, 22, 0),

      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,

            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),

              gradient: const LinearGradient(
                colors: [Color(0xFF2F6BFF), Color(0xFF00C8FF)],
              ),
            ),

            child: const Icon(Icons.hub_rounded, color: Colors.white, size: 21),
          ),

          const SizedBox(width: 12),

          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,

            children: [
              Text(
                'AI AGENT',

                style: TextStyle(
                  color: Color(0xFFF5F8FF),

                  fontSize: 16,

                  fontWeight: FontWeight.w800,

                  letterSpacing: 1.1,
                ),
              ),

              SizedBox(height: 2),

              Text(
                'VOICE COMMAND INTERFACE',

                style: TextStyle(
                  color: Color(0xFF63708A),

                  fontSize: 9,

                  letterSpacing: 1.7,

                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),

          const Spacer(),

          Container(
            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),

            decoration: BoxDecoration(
              color: const Color(0xFF07111F),

              borderRadius: BorderRadius.circular(30),

              border: Border.all(color: const Color(0xFF17345F)),
            ),

            child: const Row(
              children: [
                _LiveDot(),

                SizedBox(width: 7),

                Text(
                  'ONLINE',

                  style: TextStyle(
                    fontSize: 10,

                    color: Color(0xFF7D9FD9),

                    fontWeight: FontWeight.w700,

                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _agentCore() {
    return AnimatedBuilder(
      animation: _animation,

      builder: (context, child) {
        final active =
            _state == VoiceUiState.listening ||
            _state == VoiceUiState.thinking ||
            _state == VoiceUiState.speaking;

        final pulse = active
            ? 1 + math.sin(_animation.value * math.pi * 2) * 0.025
            : 1.0;

        return Transform.scale(
          scale: pulse,

          child: SizedBox(
            width: 228,
            height: 228,

            child: Stack(
              alignment: Alignment.center,

              children: [
                Transform.rotate(
                  angle: _animation.value * math.pi * 2,

                  child: Container(
                    width: 216,
                    height: 216,

                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,

                      gradient: SweepGradient(
                        colors: [
                          Color(0x002F6BFF),
                          Color(0xFF2F6BFF),
                          Color(0xFF00C8FF),
                          Color(0x002F6BFF),
                        ],
                      ),
                    ),

                    child: Padding(
                      padding: const EdgeInsets.all(2),

                      child: Container(
                        decoration: const BoxDecoration(
                          color: Color(0xFF02050A),

                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                  ),
                ),

                Container(
                  width: 170,
                  height: 170,

                  decoration: BoxDecoration(
                    shape: BoxShape.circle,

                    color: const Color(0xFF07101D),

                    border: Border.all(color: const Color(0xFF193B70)),

                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF2F6BFF)
                            .withOpacity(active ? .35 : .16),

                        blurRadius: active ? 50 : 25,

                        spreadRadius: active ? 8 : 2,
                      ),
                    ],
                  ),

                  child: Center(
                    child: Container(
                      width: 110,
                      height: 110,

                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,

                        gradient: RadialGradient(
                          colors: [Color(0xFF164FB5), Color(0xFF07101D)],
                        ),
                      ),

                      child: Icon(
                        _coreIcon,

                        color: const Color(0xFFCBE9FF),

                        size: 45,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _status() {
    return Column(
      children: [
        Text(
          _statusText,

          style: const TextStyle(
            color: Color(0xFF3C8BFF),

            fontSize: 11,

            fontWeight: FontWeight.w800,

            letterSpacing: 2.4,
          ),
        ),

        if (_state == VoiceUiState.listening) ...[
          const SizedBox(height: 16),

          _waveform(),
        ],
      ],
    );
  }

  Widget _waveform() {
    return AnimatedBuilder(
      animation: _animation,

      builder: (context, child) {
        return SizedBox(
          height: 36,

          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,

            children: List.generate(22, (index) {
              final value = math
                  .sin((_animation.value * math.pi * 2) + index * .55)
                  .abs();

              return Container(
                width: 3,

                height: 5 + value * 25,

                margin: const EdgeInsets.symmetric(horizontal: 2),

                decoration: BoxDecoration(
                  color: Color.lerp(
                    const Color(0xFF2F6BFF),

                    const Color(0xFF00C8FF),

                    index / 22,
                  ),

                  borderRadius: BorderRadius.circular(10),
                ),
              );
            }),
          ),
        );
      },
    );
  }

  Widget _transcriptView() {
    return Container(
      width: double.infinity,

      padding: const EdgeInsets.all(18),

      decoration: BoxDecoration(
        color: const Color(0xB307101D),

        borderRadius: BorderRadius.circular(18),

        border: Border.all(color: const Color(0xFF142A4A)),
      ),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          const Text(
            'INPUT',

            style: TextStyle(
              color: Color(0xFF536785),

              fontSize: 9,

              fontWeight: FontWeight.w800,

              letterSpacing: 1.8,
            ),
          ),

          const SizedBox(height: 9),

          Text(
            '"$_transcript"',

            style: const TextStyle(
              color: Color(0xFFE8F2FF),

              fontSize: 19,

              fontWeight: FontWeight.w500,

              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _responseView() {
    return Container(
      width: double.infinity,

      padding: const EdgeInsets.all(18),

      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF081A33), Color(0xFF07111F)],
        ),

        borderRadius: BorderRadius.circular(18),

        border: Border.all(color: const Color(0xFF20569F)),

        boxShadow: [
          BoxShadow(
            color: const Color(0xFF2F6BFF).withOpacity(.08),

            blurRadius: 30,
          ),
        ],
      ),

      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          Container(
            width: 3,
            height: 44,

            decoration: BoxDecoration(
              color: const Color(0xFF2F7BFF),

              borderRadius: BorderRadius.circular(20),
            ),
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                const Text(
                  'AGENT',

                  style: TextStyle(
                    color: Color(0xFF4B91FF),

                    fontSize: 9,

                    fontWeight: FontWeight.w800,

                    letterSpacing: 1.8,
                  ),
                ),

                const SizedBox(height: 7),

                Text(
                  _agentMessage!,

                  style: const TextStyle(
                    color: Color(0xFFF3F7FF),

                    fontSize: 17,

                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _contactView() {
    return Padding(
      padding: const EdgeInsets.only(top: 14),

      child: Column(
        children: _contacts.map((contact) {
          return Container(
            margin: const EdgeInsets.only(bottom: 10),

            decoration: BoxDecoration(
              color: const Color(0xFF07111F),

              borderRadius: BorderRadius.circular(16),

              border: Border.all(color: const Color(0xFF17345F)),
            ),

            child: ListTile(
              onTap: () => _selectContact(contact),

              leading: const CircleAvatar(
                backgroundColor: Color(0xFF10284C),

                child: Icon(Icons.person_outline, color: Color(0xFF65A9FF)),
              ),

              title: Text(
                contact.name,

                style: const TextStyle(color: Colors.white),
              ),

              subtitle: Text(
                contact.phoneNumber,

                style: const TextStyle(color: Color(0xFF70819B)),
              ),

              trailing: const Icon(
                Icons.call_rounded,

                color: Color(0xFF4C94FF),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _bottomControls() {
    final isDeepgram = _provider == AgentProvider.deepgramVoiceAgent;

    final showStop = isDeepgram
        ? _deepgramAgentCanStop
        : _state == VoiceUiState.listening;

    final disabled = isDeepgram
        ? _state == VoiceUiState.thinking ||
            _state == VoiceUiState.executing
        : _state == VoiceUiState.thinking ||
            _state == VoiceUiState.speaking ||
            _state == VoiceUiState.executing;

    final helperText = showStop
        ? (_state == VoiceUiState.speaking
            ? 'Stop response'
            : 'Tap to finish')
        : (_state == VoiceUiState.needsInput
            ? 'Tap to answer'
            : 'Tap to speak');

    return Container(
      padding: const EdgeInsets.fromLTRB(22, 10, 22, 24),
      child: Column(
        children: [
          Text(
            helperText,
            style: const TextStyle(
              color: Color(0xFF536785),
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: disabled ? null : _handleVoiceButton,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              width: 78,
              height: 78,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: disabled
                    ? null
                    : const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFF2F6BFF), Color(0xFF00A9FF)],
                      ),
                color: disabled ? const Color(0xFF101722) : null,
                boxShadow: disabled
                    ? null
                    : [
                        BoxShadow(
                          color: const Color(0xFF2F6BFF).withOpacity(.35),
                          blurRadius: 28,
                          spreadRadius: 3,
                        ),
                      ],
              ),
              child: Icon(
                showStop ? Icons.stop_rounded : Icons.mic_rounded,
                color: disabled ? const Color(0xFF445064) : Colors.white,
                size: 35,
              ),
            ),
          ),
          const SizedBox(height: 13),
          Text(
            _engineDescription,
            style: const TextStyle(
              fontSize: 8,
              color: Color(0xFF34445D),
              letterSpacing: 1.5,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _transcriptSub?.cancel();

    _finalSub?.cancel();

    unawaited(_deepgram.dispose());

    unawaited(_deepgramVoiceAgent.dispose());

    unawaited(_tts.dispose());

    _animation.dispose();

    super.dispose();
  }
}

class _LiveDot extends StatefulWidget {
  const _LiveDot();

  @override
  State<_LiveDot> createState() => _LiveDotState();
}

class _LiveDotState extends State<_LiveDot>
    with SingleTickerProviderStateMixin {
  late AnimationController controller;

  @override
  void initState() {
    super.initState();

    controller = AnimationController(
      vsync: this,

      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: Tween<double>(begin: .35, end: 1).animate(controller),

      child: Container(
        width: 7,
        height: 7,

        decoration: const BoxDecoration(
          color: Color(0xFF2F8BFF),

          shape: BoxShape.circle,
        ),
      ),
    );
  }

  @override
  void dispose() {
    controller.dispose();

    super.dispose();
  }
}
