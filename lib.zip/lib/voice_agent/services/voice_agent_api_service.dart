import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/agent_response.dart';

class VoiceAgentApiService {
  static const String baseUrl = String.fromEnvironment(
    'VOICE_AGENT_API_URL',
    defaultValue: 'https://voice-ai-agent-server.vercel.app',
  );

  static Future<AgentResponse> executeCommand(
    String text, {
    List<Map<String, String>> history = const [],
  }) async {
    final uri = Uri.parse('$baseUrl/voice-agent/execute');

    final response = await http
        .post(
          uri,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'text': text,
            'currentDateTime': _currentDateTimeWithOffset(),
            'history': history,
          }),
        )
        .timeout(const Duration(seconds: 20));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Backend error ${response.statusCode}: ${response.body}');
    }

    final decoded = jsonDecode(response.body);

    if (decoded is! Map<String, dynamic>) {
      throw Exception('Unexpected response from backend.');
    }

    final agentResponse = AgentResponse.fromJson(decoded);

    if (!agentResponse.success) {
      throw Exception(decoded['error'] ?? 'Agent request failed.');
    }

    return agentResponse;
  }

  static String _currentDateTimeWithOffset() {
    final now = DateTime.now();

    final offset = now.timeZoneOffset;

    final sign = offset.isNegative ? '-' : '+';

    final absoluteOffset = offset.abs();

    final hours = absoluteOffset.inHours.toString().padLeft(2, '0');

    final minutes = (absoluteOffset.inMinutes % 60).toString().padLeft(2, '0');

    return '${now.toIso8601String()}'
        '$sign$hours:$minutes';
  }
}
