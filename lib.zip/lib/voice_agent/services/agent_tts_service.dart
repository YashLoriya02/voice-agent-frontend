import 'dart:async';
import 'dart:convert';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class AgentTtsService {
  final AudioPlayer _player = AudioPlayer();

  bool _configured = false;
  bool _speaking = false;

  bool get isSpeaking => _speaking;

  static const String backendUrl = String.fromEnvironment(
    'VOICE_AGENT_API_URL',
    defaultValue: 'https://voice-ai-agent-server.vercel.app',
  );

  Future<void> _ensureConfigured() async {
    if (_configured) return;

    final audioContext = AudioContextConfig(
      route: AudioContextConfigRoute.speaker,
      focus: AudioContextConfigFocus.duckOthers,
      respectSilence: false,
      stayAwake: true,
    ).build();

    await _player.setAudioContext(audioContext);

    await _player.setPlayerMode(PlayerMode.mediaPlayer);

    await _player.setReleaseMode(ReleaseMode.stop);

    await _player.setVolume(1.0);

    _configured = true;
  }

  Future<Uint8List> _getAudio(String text) async {
    final response = await http
        .post(
          Uri.parse('$backendUrl/deepgram/tts'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'text': text}),
        )
        .timeout(const Duration(seconds: 10));

    if (response.statusCode != 200) {
      throw Exception('TTS HTTP ${response.statusCode}: ${response.body}');
    }

    if (response.bodyBytes.isEmpty) {
      throw Exception('TTS returned empty audio');
    }

    debugPrint('TTS received ${response.bodyBytes.length} bytes');

    return response.bodyBytes;
  }

  /// Starts TTS playback and returns as soon as
  /// playback has started.
  ///
  /// Use this BEFORE actions like:
  /// - opening YouTube
  /// - opening dialer
  /// - setting timer
  Future<void> startSpeaking(String text) async {
    final clean = text.trim();

    if (clean.isEmpty) return;

    await _ensureConfigured();

    await _player.stop();

    final bytes = await _getAudio(clean);

    _speaking = true;

    await _player.play(BytesSource(bytes));

    debugPrint('TTS playback started: $clean');
  }

  /// Speaks the whole message and waits until
  /// speech has completed.
  ///
  /// Use this for:
  /// - questions
  /// - errors
  /// - clarification requests
  Future<void> speakAndWait(String text) async {
    final clean = text.trim();

    if (clean.isEmpty) return;

    try {
      final completionFuture = _player.onPlayerComplete.first;

      await startSpeaking(clean);

      await completionFuture.timeout(const Duration(seconds: 15));
    } on TimeoutException {
      debugPrint('TTS completion timeout');
    } finally {
      _speaking = false;
    }
  }

  Future<void> stop() async {
    try {
      await _player.stop();
    } finally {
      _speaking = false;
    }
  }

  Future<void> dispose() async {
    await _player.dispose();
  }
}
