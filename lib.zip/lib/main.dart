import 'package:flutter/material.dart';
import 'package:frontend/voice_agent/screens/voice_agent_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const VoiceAgentScreen(),
    );
  }
}
